package com.mycom.hcl.dao;
import java.util.List;

import com.mycom.hcl.model.Pet;

public Pet getPetById(long PET_ID) {

public boolean savePet(Pet pet);

public List<Pet> fetchAll();


public interface PetDao {

	List<Pet> fetchAll();

	boolean savePet(Pet pet);

	Pet getPetById(long pET_ID);

}
}
