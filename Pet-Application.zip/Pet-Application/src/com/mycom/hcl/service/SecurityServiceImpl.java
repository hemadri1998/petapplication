package com.mycom.hcl.service;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.hcl.dao.UserDao;
import com.mycom.hcl.model.User;

@Service("securityService")
public class SecurityServiceImpl implements SecurityService {

	@Autowired
	private UserDao userDAO;
	private static Logger logger = (Logger) LogManager.getLogger(SecurityServiceImpl.class);

	public User authenticateUser(User user) {

		logger.debug("Authenticating " + user.getUsername());
		return userDAO.listUsers().stream().filter(a -> a.getUsername().equals(user.getUsername()))
				.filter(a -> a.getUserPassword().equals(user.getUserPassword())).findFirst().get();
	}

}