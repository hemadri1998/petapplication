package com.mycom.hcl.service;
import java.util.List;
import java.util.Set;

import com.mycom.hcl.model.Pet;
import com.mycom.hcl.model.User;

public interface PetService {
	public Pet getPetById(long PET_ID);

	public boolean savePet(Pet pet);

	public List<Pet> getAllPets();
}