package com.mycom.hcl.service;

import com.mycom.hcl.model.User;

public interface SecurityService {
	public User authenticateUser(User user) ;
}
